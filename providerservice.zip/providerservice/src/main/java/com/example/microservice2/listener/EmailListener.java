package com.example.microservice2.listener;

import org.springframework.amqp.rabbit.annotation.RabbitHandler;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

@Service
public class EmailListener {
    @RabbitListener(queues = "DEMO.QUEUE",concurrency = "2")
    public void receive(String in) {

        System.out.println("Email gonderildi");
    }
}
