package com.example.microservice2.model;

public class MyResponseList {

}
