package com.example.microservice2.controller;

import com.example.microservice2.model.Email;
import com.example.microservice2.model.MyResponse;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Mono;

import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
public class EmailController {


    @GetMapping(path = "api/author" )
    public ResponseEntity getAuthor() throws Exception
    {
System.out.println(OffsetDateTime.now());
        Email email=new Email();
        email.setName("Bilgehan YILDIZ");
        email.setSenderEmail("bilgehanyildiz@bilgehanyildiz.com");
        Thread.sleep(10000);
        System.out.println("Çağrım yapıldı");
        return ResponseEntity.ok(email);
    }

    @GetMapping(path = "api/author2" )
    public Mono<Email> getAuthorMono() throws Exception
    {

        Email email=new Email();
        email.setName("Bilgehan YILDIZ");
        email.setSenderEmail("bilgehanyildiz@bilgehanyildiz.com");
        Thread.sleep(10000);
        return Mono.just(email);
    }

    @PostMapping(path = "api/sendemail",consumes = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity createCustomer(@RequestBody Email request)
    {

        //TODO Mail Sending process
        //
        MyResponse response=new MyResponse();
        response.setResult("Email gonderildi");
        return ResponseEntity.ok(response);
    }

    @PostMapping(path = "api/sendbulk",consumes = MediaType.APPLICATION_JSON_VALUE )
    public ResponseEntity<List<Email>> senbBulkMail(@RequestBody Email request)
    {

        //TODO Mail Sending Bulk process
        //
        List<Email> emails=new ArrayList<>();
        Email email1=new Email();
        email1.setEmail("b@b.com");
        email1.setName("b");
        email1.setSenderEmail(request.getEmail());
        Email email2=new Email();
        email2.setEmail("c@c.com");
        email2.setName("c");
        email2.setSenderEmail(request.getEmail());
        emails.add(email1);
        emails.add(email2);

        return ResponseEntity.ok(emails);
    }
}
